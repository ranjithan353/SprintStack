namespace SprintStack.Enum;

public enum PriorityEnum
{
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4
}