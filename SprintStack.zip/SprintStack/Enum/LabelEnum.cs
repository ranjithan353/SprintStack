namespace SprintStack.Enum;

public enum LabelEnum
{
    Bug = 1,
    Feature = 2,
    Task = 3,
    Improvement =4
}
