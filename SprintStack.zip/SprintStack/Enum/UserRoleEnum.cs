namespace SprintStack.Enum;

public enum UserRoleEnum
{
    Admin = 1,
    Manager = 2,
    Developer = 3,
    Tester = 4
}