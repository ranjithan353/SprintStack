﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SprintStack.Migrations
{
    /// <inheritdoc />
    public partial class latest1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
