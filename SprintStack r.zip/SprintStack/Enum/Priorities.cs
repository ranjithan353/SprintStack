namespace SprintStack.Enum;

public enum Priorities
{
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4
}