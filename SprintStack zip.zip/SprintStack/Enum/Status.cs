namespace SprintStack.Enum;

public enum Status
{
    ToDo = 1,
    InProgress = 2,
    InQA = 3,
    Done = 4,
    Blocked = 5
}