namespace SprintStack.Enum;

public enum Labels
{
    Bug = 1,
    Feature = 2,
    Task = 3,
    Improvement =4
}
