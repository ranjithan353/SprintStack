namespace SprintStack.Enum;

public enum UserRoles
{
    Admin = 1,
    Manager = 2,
    Developer = 3,
    Tester = 4
}